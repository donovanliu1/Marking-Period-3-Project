return Def.Sprite {
	Texture=NOTESKIN:GetPath( '_down', 'holdi' );
	Frames = Sprite.LinearFrames( 1, 1 );
};
